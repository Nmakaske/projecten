CREATE TABLE tandartsmelding (
  id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  voornaam VARCHAR(50) NOT NULL,
  achternaam VARCHAR(50) NOT NULL,
  datum DATE NOT NULL,
);
